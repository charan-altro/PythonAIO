game = [[0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],]

print("   0  1  2")

count = 0

for row in game:
    print(count, row)
    count += 1
