game = [0, 0, 0,
        0, 0, 0,
        0, 0, 0,]

print(game)
# [0, 0, 0, 0, 0, 0, 0, 0, 0]
print(type(game))
#<class 'list'>

game = [[0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],]

print(game)

for row in game:
    print(row)
