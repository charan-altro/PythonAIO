a = int(input())
b = int(input())
print((a//b), (a/b), sep= '\n')





##Add logic to print two lines. The first line should contain the result of integer division,
##  The second line should contain the result of float division,
##No rounding or formatting is necessary.
