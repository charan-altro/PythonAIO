game = [[0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],]

print("   0  1  2")


for count, row in enumerate(game):
    print(count, row)
