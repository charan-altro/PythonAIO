game = [[0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],]

#print(game)

for row in game:
    print(row)
